<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\htdocs\laravel\FloodView2\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>