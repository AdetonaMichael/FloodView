<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="author" content="Michael Adetona" />
        <title><?php echo e(config('app.name', 'Flood View')); ?></title>

                <!-- OG Meta Tags to improve the way the post looks when you share the page on Facebook, Twitter, LinkedIn -->
                <meta property="og:site_name" content="" /> <!-- website name -->
                <meta property="og:site" content="" /> <!-- website link -->
                <meta property="og:title" content="" /> <!-- title shown in the actual shared post -->
                <meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
                <meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
                <meta property="og:url" content="" /> <!-- where do you want your post to link to -->
                <meta name="twitter:card" content="summary_large_image" /> <!-- to have large image post format in Twitter -->
                <link rel="icon" href="<?php echo e(asset('img/rain.png')); ?>" />
        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">
        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link href="css/styles.css" rel="stylesheet" />
        <?php echo $__env->yieldContent('css'); ?>
        <?php echo \Livewire\Livewire::styles(); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>">
        <script src="https://cdn.tiny.cloud/1/914cbs1n4e1r1683f7ere86yes0kemwesp1tctsdsft2pq6k/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            

            <!-- Page Content -->
            <main>

             <?php echo $__env->yieldContent('content'); ?>

            </main>
        </div>
           <!-- Scripts -->

           <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
           <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
           <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
           <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
        <?php echo \Livewire\Livewire::scripts(); ?>

        <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>

        <script>
        <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(session()->get('success')); ?>")
        <?php elseif(Session::has('error')): ?>
        toastr.error("<?php echo e(session()->get('success')); ?>")
        <?php endif; ?>
        </script>

        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\htdocs\laravel\FloodView2\resources\views/layouts/app.blade.php ENDPATH**/ ?>