


                    <!-- Footer : BEGIN -->
                    <tr>
                        <td
                            style="text-align:center; padding:4% 0; font-family:sans-serif; font-size:13px; line-height:1.2; color:#666666;">
                            You received this email because you opted in to our newsletter.
                            <br><br>
                            Obafemi Awolowo University &bull; <span class="mobile-link--footer">Road 1</span> &bull; <span class="mobile-link--footer">(+234) 3820-323</span>
                            <br><br>
                            <unsubscribe style="color:#666666; text-decoration:underline;">unsubscribe</unsubscribe>
                        </td>
                    </tr>
                    <!-- Footer : END -->

                </table>
                <!-- Email wrapper : END -->

                <!-- End of Outlook-specific wrapper : BEGIN -->
                <!--[if (gte mso 9)|(IE)]>
      </td>
    </tr>
  </table>
  <![endif]-->
                <!-- End of Outlook-specific wrapper : END -->

            </td>
        </tr>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\htdocs\laravel\FloodView2\resources\views/vendor/mail/html/footer.blade.php ENDPATH**/ ?>