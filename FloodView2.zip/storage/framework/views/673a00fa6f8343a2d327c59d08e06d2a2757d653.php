

<div>
    
        <form wire:submit.prevent="storeReport">
    
            <div class="bg-white p-4 sm:px-6 sm:py-4 border-b border-gray-150">
                <?php if(isset($title)): ?>
                    <h3 class="text-lg leading-6 font-medium text-gray-900">
                        <?php echo e($title); ?>

                    </h3>
                <?php endif; ?>
            </div>
            <div class="bg-white px-4 sm:p-6">
                <div class="space-y-6">
                    <?php echo e($content); ?>

                </div>
            </div>

            <div class="bg-white px-4 pb-5 sm:px-4 sm:flex">
                <?php echo e($buttons); ?>

            </div>
    
        </form>
    
</div>
<?php /**PATH C:\xampp\htdocs\htdocs\laravel\FloodView2\resources\views/components/modal.blade.php ENDPATH**/ ?>