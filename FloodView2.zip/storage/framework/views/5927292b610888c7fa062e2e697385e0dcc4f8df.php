

<div style="display:flex; justify-content: center;">
    <a target="_blank" rel="noopener"  style="text-decoration:none; background-color:orangered; color:white; text-center; border-radius:45px; padding-left:40px; padding-right:40px; padding-top:10px; padding-bottom:10px;" href="<?php echo e($url); ?>" target="_blank"><?php echo e($slot); ?></a>
</div>
<?php /**PATH C:\xampp\htdocs\htdocs\laravel\FloodView2\resources\views/vendor/mail/html/button.blade.php ENDPATH**/ ?>