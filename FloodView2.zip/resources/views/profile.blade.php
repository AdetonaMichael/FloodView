@extends('layouts.app')
@section('content')
@livewire('profile');
@endsection
