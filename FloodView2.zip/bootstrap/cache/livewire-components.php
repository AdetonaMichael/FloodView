<?php return array (
  'create-report' => 'App\\Http\\Livewire\\CreateReport',
  'profile' => 'App\\Http\\Livewire\\Profile',
);