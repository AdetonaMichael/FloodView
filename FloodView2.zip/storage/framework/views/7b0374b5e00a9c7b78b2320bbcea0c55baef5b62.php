



<?php echo e($header ?? ''); ?>


     <!-- Main Email Body : BEGIN -->
     <table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#ffffff">

        <!-- Single Fluid Image, No Crop : BEGIN -->
        <tr>
            <td valign="middle" align="center" style="padding-top:4%;">
                <img src="https://cdn.pixabay.com/photo/2015/09/30/08/33/flood-965092_960_720.jpg"
                    alt="alt text" align="center" border="0" style="margin: auto;">
            </td>
        </tr>
        <!-- Single Fluid Image, No Crop : END -->

        <!-- Full Width, Fluid Column : BEGIN -->
        <tr>
            <td
                style="padding: 4%; font-family: sans-serif; font-size: 18px; line-height: 1.3; color: #666666;">
                <?php echo e($slot); ?>


                <br/><br/>

            </td>
            
        </tr>
        <!-- Full Width, Fluid Column : END -->



        

    </table>
    <!-- Main Email Body : END -->

</td>
</tr>

<?php echo e($footer ?? ''); ?>


<?php /**PATH C:\xampp\htdocs\htdocs\laravel\FloodView2\resources\views/vendor/mail/html/layout.blade.php ENDPATH**/ ?>