<?php $__env->startSection('content'); ?>

<button class="m-5 float-right btn-outline-reg first-line@aware(['propName'])inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest   focus:outline-none  focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150" onclick="Livewire.emit('openModal','create-report')">Create Report</button>
        <!-- Details 2 -->

  <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="py-24">
    <div class="container px-4 sm:px-8 lg:grid lg:grid-cols-12 lg:gap-x-12">
        <div class="lg:col-span-7">
            <div class="mb-12 lg:mb-0 xl:mr-14">
                <img class="inline" src="images/details-2.jpg" alt="alternative" />
            </div>

            <div class="flex">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="storage/<?php echo e(($item)); ?>" alt="image" />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


        </div> <!-- end of col -->
        <div class="lg:col-span-5">
            <div class="xl:mt-12">
                <h2 class="mb-6"><?php echo e($report->street.",".$report->state); ?></h2>
                <ul class="list mb-7 space-y-2">
                    <li class="flex">
                        <i class="fas fa-chevron-right"></i>
                        <div class="text-xl text-green-600">Coordinate: <?php echo e($report->location); ?>                         <i class="fa fa-location-dot fa-2xl pl-2"></i></div>

                    </li>
                    <li class="flex">
                        <i class="fas fa-chevron-right"></i>
                        <div class="text-xl"><span class="text-red-600">Description:</span> <?php echo e($report->description); ?></div>
                    </li>
                    <li class="flex">
                        <i class="fas fa-chevron-right"></i>
                        <div class="text-xl"><span class="text-red-600">Date Reproted</span> <?php echo e($report->created_at); ?></div>
                    </li>
                    <li class="flex">
                        <i class="fas fa-chevron-right"></i>
                        <div class="text-xl"><span class="text-red-600">Posted By:</span><?php echo e($report->user->name); ?></div>
                    </li>
                </ul>
                <a class="btn-solid-reg popup-with-move-anim mr-1.5" href="#details-lightbox">Contribute</a>
                <a class="btn-outline-reg" href="article.html">Details</a>
            </div>
        </div> <!-- end of col -->
    </div> <!-- end of container -->
</div>
<!-- end of details 2 -->
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('livewire-ui-modal')->html();
} elseif ($_instance->childHasBeenRendered('s8kyTmi')) {
    $componentId = $_instance->getRenderedChildComponentId('s8kyTmi');
    $componentTag = $_instance->getRenderedChildComponentTagName('s8kyTmi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('s8kyTmi');
} else {
    $response = \Livewire\Livewire::mount('livewire-ui-modal');
    $html = $response->html();
    $_instance->logRenderedChild('s8kyTmi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\htdocs\laravel\FloodView2\resources\views/reports.blade.php ENDPATH**/ ?>