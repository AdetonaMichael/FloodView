<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
            <!-- SEO Meta Tags -->
        <meta name="description" content="Pavo is a mobile app Tailwind CSS HTML template created to help you present benefits, features and information about mobile apps in order to convince visitors to download them" />
        <meta name="author" content="Your name" />

        <!-- OG Meta Tags to improve the way the post looks when you share the page on Facebook, Twitter, LinkedIn -->
        <meta property="og:site_name" content="" /> <!-- website name -->
        <meta property="og:site" content="" /> <!-- website link -->
        <meta property="og:title" content="" /> <!-- title shown in the actual shared post -->
        <meta property="og:description" content="" /> <!-- description shown in the actual shared post -->
        <meta property="og:image" content="" /> <!-- image link, make sure it's jpg -->
        <meta property="og:url" content="" /> <!-- where do you want your post to link to -->
        <meta name="twitter:card" content="summary_large_image" /> <!-- to have large image post format in Twitter -->

        <!-- Webpage Title -->
        <title>Flood View</title>

        <!-- Styles -->
        <link rel="preconnect" href="https://fonts.gstatic.com" />
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link href="css/swiper.css" rel="stylesheet" />
        
        <link href="css/styles.css" rel="stylesheet" />

        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <!-- Favicon  -->
        <link rel="icon" href="<?php echo e(asset('img/rain.png')); ?>" />
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />

    </head>
    <body data-spy="scroll" data-target=".fixed-top">

        <!-- Navigation -->
        <nav class="navbar fixed-top">
            <div class="container sm:px-4 lg:px-8 flex flex-wrap items-center justify-between lg:flex-nowrap">

                <!-- Text Logo - Use this if you don't have a graphic logo -->
                <!-- <a class="text-gray-800 font-semibold text-3xl leading-4 no-underline page-scroll" href="index.html">Pavo</a> -->

                <!-- Image Logo -->
                <a class="inline-block mr-4 py-0.5 text-xl whitespace-nowrap hover:no-underline focus:no-underline" href="index.html">
                   <p class="font-bold text-2xl uppercase">Flood View</p>
                </a>

                <button class="background-transparent rounded text-xl leading-none hover:no-underline focus:no-underline lg:hidden lg:text-gray-400" type="button" data-toggle="offcanvas">
                    <span class="navbar-toggler-icon inline-block w-8 h-8 align-middle"></span>
                </button>

                <div class="navbar-collapse offcanvas-collapse lg:flex lg:flex-grow lg:items-center" id="navbarsExampleDefault">
                    <ul class="pl-0 mt-3 mb-2 ml-auto flex flex-col list-none lg:mt-0 lg:mb-0 lg:flex-row">
                        <li>
                            <a class="nav-link page-scroll active" href="#header">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li>
                            <a class="nav-link page-scroll" href="/reports">Reports</a>
                        </li>
                        <li>
                            <a class="nav-link page-scroll" href="#details">Details</a>
                        </li>
                        <li>
                            <a class="nav-link page-scroll" href="#pricing">Pricing</a>
                        </li>
                        <li class="dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Drop</a>
                            <div class="dropdown-menu" aria-labelledby="dropdown01">
                                <a class="dropdown-item page-scroll" href="article.html">Article Details</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item page-scroll" href="terms.html">Terms Conditions</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item page-scroll" href="privacy.html">Privacy Policy</a>
                            </div>
                        </li>
                        <li>
                            <a class="nav-link page-scroll" href="#download">Download</a>
                        </li>
                    </ul>
                    <span class="block lg:ml-3.5">
                        <a class="no-underline" href="#your-link">
                            <i class="fab fa-apple text-indigo-600 hover:text-pink-500 text-xl transition-all duration-200 mr-1.5"></i>
                        </a>
                        <a class="no-underline" href="#your-link">
                            <i class="fab fa-android text-indigo-600 hover:text-pink-500 text-xl transition-all duration-200"></i>
                        </a>
                    </span>
                </div> <!-- end of navbar-collapse -->
            </div> <!-- end of container -->
        </nav> <!-- end of navbar -->
        <!-- end of navigation -->

        <!-- Header -->
        
        <!-- end of header -->
        <header class="masthead">
            <div id="hero-caption" class="row text-center">
                <a href="#" class="px-10 py-5 font-bold text-upper rounded-full  bg-orange-600  text-white uppercase ">Get Alert  <i class="fas fa-phone-flip pl-2 fa-2x"></i></a>
                    <h1 id="hero-title" class="font-bold text-gray-300 mb-10 mt-10">Get Flood Alert on your Mobile phone </h1>


                    <div id="weather" class="weather bg-white rounded-lg relative top-10  p-5">
                        <p class="text-white text-2xl font-bold font-seri my-4">Expect Rain showers Tomorrow...</p>
                        <form class="cityForm" action="#">
                            <div class="md:flex md:justify-center">
                                <i class="fas fa-search fa-2x  top-2 relative left-10"></i>
                                <input id="city_input" class="md:w-2/4 w-full py-3 pl-2 rounded-full" name="city" type="text">
                            </div>
                        </form>
                        <a class="relative top-10  px-10 py-4 rounded-full bg-gray-700 text-white font-bold text-xl opacity-50 hover:text-white hover:bg-gray-600 mt-4" href="#">See full forcast <i class="fas fa-angle-right"></i></a>

                    </div>
            </div>

        </header>

        <!-- Introduction -->
        <div class="pt-4 pb-14 text-center">

        </div>
        <!-- end of introduction -->


        <!-- Features -->
        <div id="features" class="cards-1">
            <div class="container-fluid px-4 sm:px-8 xl:px-4">
            <div class="md:grid md:grid-cols-4  ">
                <!-- Card -->
                <div class="card">
                   <div class="card-image">
                       <img src="images/features-icon-1.svg" alt="alternative" />
                   </div>
                   <div class="card-body">
                       <h5 class="card-title">Notification </h5>
                       <p class="mb-4">Get Flood Analysis Notification and Updates</p>
                   </div>
               </div>
               <!-- end of card -->

               <!-- Card -->
               <div class="card">
                   <div class="card-image">
                       <img src="images/features-icon-2.svg" alt="alternative" />
                   </div>
                   <div class="card-body">
                       <h5 class="card-title">Statistics</h5>
                       <p class="mb-4">Visualize flood Analysis For your area of Intrest</p>
                   </div>
               </div>
               <!-- end of card -->

               <!-- Card -->
               <div class="card">
                   <div class="card-image">
                       <img src="images/features-icon-3.svg" alt="alternative" />
                   </div>
                   <div class="card-body">
                       <h5 class="card-title">Cummunity Report</h5>
                       <p class="mb-4">Optimized code and innovative technology insure no delays and ultra-fast responsiveness</p>
                   </div>
               </div>
               <!-- end of card -->

               <!-- Card -->
               <div class="card">
                   <div class="card-image">
                       <img src="images/features-icon-4.svg" alt="alternative" />
                   </div>
                   <div class="card-body">
                       <h5 class="card-title">Multiple Languages</h5>
                       <p class="mb-4">Choose from one of the 40 languages that come pre-installed and start selling smarter</p>
                   </div>
               </div>
                 </div>



            </div> <!-- end of container -->
        </div> <!-- end of cards-1 -->
        <!-- end of features -->

        <!--map section -->


            <div style="height:50%; width:100%; margin:auto; position:absolute;" id="map" class="">

            </div>

        <!-- Details 1 -->
        
        <!-- end of details 1 -->


        <!-- Details 2 -->
        <div class="py-24">
            <div class="container px-4 sm:px-8 lg:grid lg:grid-cols-12 lg:gap-x-12">
                <div class="lg:col-span-7">
                    <div class="mb-12 lg:mb-0 xl:mr-14">
                        <img class="inline" src="images/details-2.jpg" alt="alternative" />
                    </div>
                </div> <!-- end of col -->
                <div class="lg:col-span-5">
                    <div class="xl:mt-12">
                        <h2 class="mb-6">Instant results for the marketing department</h2>
                        <ul class="list mb-7 space-y-2">
                            <li class="flex">
                                <i class="fas fa-chevron-right"></i>
                                <div>Features that will help you and your marketers</div>
                            </li>
                            <li class="flex">
                                <i class="fas fa-chevron-right"></i>
                                <div>Smooth learning curve due to the knowledge base</div>
                            </li>
                            <li class="flex">
                                <i class="fas fa-chevron-right"></i>
                                <div>Ready out-of-the-box with minor setup settings</div>
                            </li>
                        </ul>
                        <a class="btn-solid-reg popup-with-move-anim mr-1.5" href="#details-lightbox">Lightbox</a>
                        <a class="btn-outline-reg" href="article.html">Details</a>
                    </div>
                </div> <!-- end of col -->
            </div> <!-- end of container -->
        </div>
        <!-- end of details 2 -->


        <!-- Details Lightbox -->
        <!-- Lightbox -->
        
        <!-- end of lightbox -->
        <!-- end of details lightbox -->


        <!-- Details 3 -->
        <div class="pt-16 pb-12">
            <div class="container px-4 sm:px-8 lg:grid lg:grid-cols-12 lg:gap-x-12">
                <div class="lg:col-span-5">
                    <div class="mb-16 lg:mb-0 xl:mt-16">
                        <h2 class="mb-6">Platform integration and life time free updates</h2>
                        <p class="mb-4">Get a glimpse of what this app can do for your marketing automation and understand why current users are so excited when using Pavo
                            together with their teams.</p>
                        <p class="mb-4">We will promptly answer any questions and honor your requests based on the service level agreement</p>
                    </div>
                </div> <!-- end of col -->
                <div class="lg:col-span-7">
                    <div class="ml-14">
                        <img class="inline" src="images/details-3.jpg" alt="alternative" />
                    </div>
                </div> <!-- end of col -->
            </div> <!-- end of container -->
        </div>
        <!-- end of details 3 -->




        <!-- Testimonials -->
        
        <!-- end of testimonials -->


        <!-- Pricing -->
        
        <!-- end of pricing -->


        <!-- Conclusion -->
        
        <!-- end of conclusion -->


        

              <!-- Statistics -->
              <div class="counter">
                <div class="container px-4 sm:px-8">

                    <!-- Counter -->
                    <div id="counter" class="grid grid-cols-2 md:grid md:grid-cols-4 gap-2">
                        <div class="">
                            <div class="counter-value number-count text-gray-500" data-count="231">1</div>
                            <p class="counter-info text-gray-700">Registered Users</p>
                        </div>
                        <div class="">
                            <div class="counter-value number-count text-gray-500" data-count="385">1</div>
                            <p class="counter-info text-gray-700">Issues Solved</p>
                        </div>
                        <div class="">
                            <div class="counter-value number-count text-gray-500" data-count="159">1</div>
                            <p class="counter-info text-gray-700">Notifications Sent</p>
                        </div>
                        <div class="">
                            <div class="counter-value number-count text-gray-500" data-count="127">1</div>
                            <p class="counter-info text-gray-700">Case Studies</p>
                        </div>

                    </div>
                    <!-- end of counter -->

                </div> <!-- end of container -->
            </div> <!-- end of counter -->
            <!-- end of statistics -->


        <!-- Copyright -->
        <div class="copyright">
            <div class="container px-4 sm:px-8 lg:grid lg:grid-cols-3">
                <ul class="mb-4 list-unstyled p-small">
                    <li class="mb-2"><a href="article.html">Article Details</a></li>
                    <li class="mb-2"><a href="terms.html">Terms & Conditions</a></li>
                    <li class="mb-2"><a href="privacy.html">Privacy Policy</a></li>
                </ul>
                <p class="pb-2 p-small statement text-white">Copyright © <a href="#your-link" class="no-underline">Flood View</a></p>

            </div>

        <!-- end of container -->
        </div> <!-- end of copyright -->
        <!-- end of copyright -->


        <!-- Scripts -->
        <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
        <script src="<?php echo e(asset('js/leaflet_code.js')); ?>"></script>
        <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/forcast.js')); ?>"></script>
        <script src="js/jquery.min.js"></script> <!-- jQuery for JavaScript plugins -->
        <script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
        <script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
        
        <script src="js/scripts.js"></script> <!-- Custom scripts -->

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\htdocs\laravel\FloodView2\resources\views/welcome.blade.php ENDPATH**/ ?>