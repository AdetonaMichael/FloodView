
<img src="<?php echo e(asset('img/rain.png')); ?>" class="h-10 w-10" alt="Flood View Image">
<?php /**PATH C:\xampp\htdocs\htdocs\laravel\FloodView2\resources\views/components/application-logo.blade.php ENDPATH**/ ?>